#include "keyfeaturesform.h"
#include "ui_keyfeaturesform.h"

#include <QSqlDatabase>
#include <QSqlTableModel>
#include <QSqlQuery>
#include <QSettings>

KeyFeaturesForm::KeyFeaturesForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::KeyFeaturesForm)
{
    ui->setupUi(this);

    ui->verticalSpacer->changeSize(10,10);
    ui->verticalSpacer_2->changeSize(10,10);

//    QSettings settings;
//    ui->zoomInCheckBox->setChecked(settings.value("checkstate").toBool());

    loadData();
//    productData();
}

KeyFeaturesForm::~KeyFeaturesForm()
{
    delete ui;
}

void KeyFeaturesForm::on_zoomInCheckBox_stateChanged(int arg1)
{
//    QSettings settings;
//    settings.setValue("checkstate", ui->zoomInCheckBox->isChecked());

}

void KeyFeaturesForm::loadData()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE", "keyConnection");        // 데이터베이스를  만듦
    db.setDatabaseName("keyDBlist.db");                                             // DB이름 : keyDBlist
    if(db.open()) {                                                                 // DB를 열 때
        QSqlQuery query(db);                                                        // DB에 커리생성

        /* 테이블을 생성하고 0~3열까지 헤더 이름을 지정해줍니다. */
        query.exec("CREATE TABLE IF NOT EXISTS KeytDB(id INTEGER Primary Key,"
                   "check VARCHAR(30) NOT NULL, price VARHCHAR(20));");
        keyModel = new QSqlTableModel(this, db);
        keyModel->setTable("KeytDB");                                               // 테이블명 : KeytDB
        keyModel->select();                                                         // keyModel을 재정렬
        /* 제품 tableView의 0~1열까지 헤더 이름을 지정 */
        keyModel->setHeaderData(0, Qt::Horizontal, tr("Doctor ID"));
        keyModel->setHeaderData(1, Qt::Horizontal, tr("Check"));
        keyModel->setHeaderData(2, Qt::Horizontal, tr("price"));
        ui->tableView->setModel(keyModel);                                          // tableView에 지정해준 헤더 이름을 가진 모델을 보여줍니다.
        ui->tableView->resizeColumnsToContents();
    }
}


void KeyFeaturesForm::productData()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE", "productConnection");    // 데이터베이스를  만듦
    db.setDatabaseName("ProductDBlist.db");                                         // DB이름 : ProductDBlist
    if(db.open()) {                                                                 // DB를 열 때
        QSqlQuery query(db);                                                        // DB에 커리생성

        /* 테이블을 생성하고 0~3열까지 헤더 이름을 지정해줍니다. */
        query.exec("CREATE TABLE IF NOT EXISTS ProductDB(id INTEGER Primary Key,"
                   "productName VARCHAR(30) NOT NULL, price VARHCHAR(20), inventoryAmount INTEGER);");
        productModel = new QSqlTableModel(this, db);
        productModel->setTable("ProductDB");                                        // 테이블명 : ProductDB
        productModel->select();                                                     // productModel을 재정렬
        /* 제품 tableView의 0~3열까지 헤더 이름을 지정 */
        productModel->setHeaderData(0, Qt::Horizontal, tr("제품 ID"));
        productModel->setHeaderData(1, Qt::Horizontal, tr("제품 이름"));
        productModel->setHeaderData(2, Qt::Horizontal, tr("가격"));
        productModel->setHeaderData(3, Qt::Horizontal, tr("재고 수량"));
        ui->tableView->setModel(productModel);                                      // tableView에 지정해준 헤더 이름을 가진 모델을 보여줍니다.
        ui->tableView->resizeColumnsToContents();                                   // 이름 크기에 맞기 사이즈를 지정해 줌
    }
}

