#include "view.h"


#include <QDebug>
#include <QMouseEvent>
#include <QScrollBar>
#include <QGraphicsView>

#include <QMenu>
#include <QStatusBar>
#include <QSettings>


View::View(QWidget *parent)
    : QGraphicsView{parent}
{
    //QAction* removeAction = new QAction(tr("&Remove"));
    //connect(removeAction, SIGNAL(triggered()), SLOT(removeItem()));     // remove할 때 시그널 슬롯 발생
    zoomInAction = new QAction(tr("&Zoom In"));
    zoomOutAction = new QAction(tr("&Zoom Out"));
    leftRotateAction = new QAction(tr("&90° Rotate"));
    rightRotateAction = new QAction(tr("&-90° Rotate"));
    brushAction = new QAction(tr("&Brush"));
    rectangleAction = new QAction(tr("&Rectangle"));
    triangleAction = new QAction(tr("&Triangle"));
    ellipseAction = new QAction(tr("&Ellipse"));
    moveShapeAction = new QAction(tr("&Move Shape"));
    blendingAction = new QAction(tr("&Blending"));
    lengthMeasurementAction = new QAction(tr("&Length Measurement"));
    angleMeasurementAction = new QAction(tr("&Angle Measurement"));
    brightnessAction = new QAction(tr("&Brightness"));
    darknessAction = new QAction(tr("&Darkness"));
    sharpenAction = new QAction(tr("&Sharpen"));
    contrastAction = new QAction(tr("&Contrast"));
    inversionAction = new QAction(tr("&Inversion"));
    horizontalFlipAction = new QAction(tr("&Horizontal Flip"));
    verticalFlipAction = new QAction(tr("&Vertical Flip"));
    implantAction = new QAction(tr("&Implant"));

    menu = new QMenu;    // menu : 멤버변수, 메뉴 생성

    connect(zoomInAction, SIGNAL(triggered()), SLOT(zoomInKey()));
    checkStateShow();    // 체크 상태 된 가능만 메뉴바에 생성됨

    this->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(this, SIGNAL(customContextMenuRequested(QPoint)), this, SLOT(showContextMenu(QPoint)));
}

void View::zoomInKey()
{
    qDebug() << "트리거됨";
    emit sig_zoomIn();
    qDebug() << "시그널 전달";
}

void View::showContextMenu(const QPoint &pos)
{
    QPoint globalPos = this->mapToGlobal(pos);
    menu->exec(globalPos);
}

void View::checkStateShow()
{
    QSettings CheckBox(QString("./CheckBox/%1.ini").arg("CheckStateFile"), QSettings::IniFormat);
    CheckBox.beginGroup("checking");

    if(CheckBox.value("checkState1") == true)
        menu->addAction(zoomInAction);
    if(CheckBox.value("checkState2") == true)
        menu->addAction(zoomOutAction);
    if(CheckBox.value("checkState3") == true)
        menu->addAction(leftRotateAction);
    if(CheckBox.value("checkState4") == true)
        menu->addAction(rightRotateAction);
    if(CheckBox.value("checkState5") == true)
        menu->addAction(brushAction);
    if(CheckBox.value("checkState6") == true)
        menu->addAction(rectangleAction);
    if(CheckBox.value("checkState7") == true)
        menu->addAction(triangleAction);
    if(CheckBox.value("checkState8") == true)
        menu->addAction(ellipseAction);
    if(CheckBox.value("checkState9") == true)
        menu->addAction(moveShapeAction);
    if(CheckBox.value("checkState10") == true)
        menu->addAction(blendingAction);
    if(CheckBox.value("checkState11") == true)
        menu->addAction(lengthMeasurementAction);
    if(CheckBox.value("checkState12") == true)
        menu->addAction(angleMeasurementAction);
    if(CheckBox.value("checkState13") == true)
        menu->addAction(brightnessAction);
    if(CheckBox.value("checkState14") == true)
        menu->addAction(darknessAction);
    if(CheckBox.value("checkState15") == true)
        menu->addAction(sharpenAction);
    if(CheckBox.value("checkState16") == true)
        menu->addAction(contrastAction);
    if(CheckBox.value("checkState17") == true)
        menu->addAction(inversionAction);
    if(CheckBox.value("checkState18") == true)
        menu->addAction(horizontalFlipAction);
    if(CheckBox.value("checkState19") == true)
        menu->addAction(verticalFlipAction);
    if(CheckBox.value("checkState20") == true)
        menu->addAction(implantAction);
    CheckBox.endGroup();
}


void View::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::RightButton)
    {
        _pan = true;
        _panStartX = event->x();
        _panStartY = event->y();
        setCursor(Qt::ArrowCursor);
        event->accept();
        return;
    }
    event->ignore();   
}

void View::mouseReleaseEvent(QMouseEvent *event)
{
    if (event->button() == Qt::RightButton)
    {
        _pan = false;
        setCursor(Qt::ArrowCursor);
        event->accept();
        return;
    }
    event->ignore();
}

void View::mouseMoveEvent(QMouseEvent *event)
{
    if (_pan)
    {
        horizontalScrollBar()->setValue(horizontalScrollBar()->value() - (event->x() - _panStartX));
        verticalScrollBar()->setValue(verticalScrollBar()->value() - (event->y() - _panStartY));
        _panStartX = event->x();
        _panStartY = event->y();
        setCursor(Qt::ClosedHandCursor);
        event->accept();
        return;
    }
    event->ignore();
}

void View::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
    qDebug() << "호버가 되나요?";
}
