#ifndef VIEW_H
#define VIEW_H

#include <QGraphicsView>

class KeyFeaturesForm;

class View : public QGraphicsView
{
    Q_OBJECT
public:
    explicit View(QWidget *parent = nullptr);

    bool _pan;
    int _panStartX, _panStartY;

    void checkStateShow();



    QMenu* menu;

    QAction* zoomInAction;
    QAction* zoomOutAction;
    QAction* leftRotateAction;
    QAction* rightRotateAction;
    QAction* brushAction;
    QAction* rectangleAction;
    QAction* triangleAction;
    QAction* ellipseAction;
    QAction* moveShapeAction;
    QAction* blendingAction;
    QAction* lengthMeasurementAction;
    QAction* angleMeasurementAction;
    QAction* brightnessAction;
    QAction* darknessAction;
    QAction* sharpenAction;
    QAction* contrastAction;
    QAction* inversionAction;
    QAction* horizontalFlipAction;
    QAction* verticalFlipAction;
    QAction* implantAction;

public slots:
    void zoomInKey();


protected:
    void mouseMoveEvent(QMouseEvent *event);
    void mousePressEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
    void hoverEnterEvent(QGraphicsSceneHoverEvent* event);

private:
    KeyFeaturesForm *keyFeatures;





private slots:
    void showContextMenu(const QPoint &);


signals:
    void sig_zoomIn();

};

#endif // VIEW_H
