#ifndef KEYFEATURESFORM_H
#define KEYFEATURESFORM_H

#include "qsettings.h"
#include <QWidget>

class QSqlQuery;
class QSqlTableModel;
class QSettings;


namespace Ui {
class KeyFeaturesForm;
}

class KeyFeaturesForm : public QWidget
{
    Q_OBJECT

public:
    explicit KeyFeaturesForm(QWidget *parent = nullptr);
    ~KeyFeaturesForm();


    void loadData();
    QSettings settings;

    void productData();


private slots:
    void on_zoomInCheckBox_stateChanged(int arg1);


private:
    Ui::KeyFeaturesForm *ui;

    QSqlTableModel* keyModel;                            // 주요 기능 커리모델
    QSqlTableModel* productModel;

};

#endif // KEYFEATURESFORM_H
