#ifndef KEYFEATURESFORM_H
#define KEYFEATURESFORM_H

#include <QWidget>

namespace Ui {
class KeyFeaturesForm;
}

class KeyFeaturesForm : public QWidget
{
    Q_OBJECT

public:
    explicit KeyFeaturesForm(QWidget *parent = nullptr);
    ~KeyFeaturesForm();

private:
    Ui::KeyFeaturesForm *ui;
};

#endif // KEYFEATURESFORM_H
