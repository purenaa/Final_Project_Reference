#ifndef KEYFEATURESFORM_H
#define KEYFEATURESFORM_H

#include "qsettings.h"
#include <QWidget>

class QSettings;


namespace Ui {
class KeyFeaturesForm;
}

class KeyFeaturesForm : public QWidget
{
    Q_OBJECT

public:
    explicit KeyFeaturesForm(QWidget *parent = nullptr);
    ~KeyFeaturesForm();


    QSettings settings;


private slots:
    void on_zoomInCheckBox_stateChanged(int arg1);

    void on_zoomInCheckBox_clicked();

private:
    Ui::KeyFeaturesForm *ui;
};

#endif // KEYFEATURESFORM_H
