#include "keyfeaturesform.h"
#include "ui_keyfeaturesform.h"

#include <QSettings>

KeyFeaturesForm::KeyFeaturesForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::KeyFeaturesForm)
{
    ui->setupUi(this);

    ui->verticalSpacer->changeSize(10,10);
    ui->verticalSpacer_2->changeSize(10,10);

    QSettings settings;
    ui->zoomInCheckBox->setChecked(settings.value("checkstate").toBool());

}

KeyFeaturesForm::~KeyFeaturesForm()
{
    delete ui;
}

void KeyFeaturesForm::on_zoomInCheckBox_stateChanged(int arg1)
{
//    QSettings settings;
//    settings.setValue("checkstate", ui->zoomInCheckBox->isChecked());

}


void KeyFeaturesForm::on_zoomInCheckBox_clicked()
{

}

