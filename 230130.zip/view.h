#ifndef VIEW_H
#define VIEW_H

#include <QGraphicsView>

class KeyFeaturesForm;
class Layout;

class View : public QGraphicsView
{
    Q_OBJECT
public:
    explicit View(QWidget *parent = nullptr);

    bool _pan;
    int _panStartX, _panStartY;

    QPointF clickPoint;



    QMenu* menu;

    QAction* zoomInAction;
    QAction* zoomOutAction;
    QAction* leftRotateAction;
    QAction* rightRotateAction;
    QAction* brushAction;
    QAction* rectangleAction;
    QAction* triangleAction;
    QAction* ellipseAction;
    QAction* moveShapeAction;
    QAction* blendingAction;
    QAction* lengthMeasurementAction;
    QAction* angleMeasurementAction;
    QAction* brightnessAction;
    QAction* darknessAction;
    QAction* sharpenAction;
    QAction* contrastAction;
    QAction* inversionAction;
    QAction* horizontalFlipAction;
    QAction* verticalFlipAction;
    QAction* implantAction;

public slots:
    void zoomInKey();
    void checkStateShow();



protected:
    void mouseMoveEvent(QMouseEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseReleaseEvent(QMouseEvent *event) override;
    void mouseDoubleClickEvent(QMouseEvent *event) override;

    void hoverEnterEvent(QGraphicsSceneHoverEvent* event);

private:







private slots:
    void showContextMenu(const QPoint &);


signals:
    void sig_zoomIn();
//    void sig_sheckShow();

};

#endif // VIEW_H
