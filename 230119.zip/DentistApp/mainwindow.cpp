#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "layout.h"
#include "fmx.h"
//#include "listalbum.h"

/* 환자 정보 DB */
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlTableModel>
#include <QSqlQueryModel>
#include <QTableView>



#include <QSplitter>
#include <QListWidget>
#include <QDir>
#include <QFileInfo>
#include <QPalette>
#include <QMdiSubWindow>
#include <QGraphicsItem>
#include <QGraphicsPathItem>
#include <QMouseEvent>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QPoint>
#include <QRectF>





#define sheetWhite "background:rgb(255, 255, 255)"
#define sheetNavy "background:rgb(32, 56, 100)"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    styleColor();                                   // ui 색상 조절 및 크기 조절 함수

    ui->listWidget->setIconSize(QSize(130, 80));
    ui->listWidget->setResizeMode(QListWidget::Adjust);
    ui->listWidget->setFlow(QListWidget::LeftToRight);
    ui->listWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->listWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);


    connect(ui->listWidget, SIGNAL(itemClicked(QListWidgetItem*)), SLOT(selectItem(QListWidgetItem*)));

//    connect(, SIGNAL(sig_layoutInfo1)))

//    connect(customLayout->grid1, SIGNAL(clicked()), SLOT(selectGrid(QGraphicsView*)));
//    connect(customLayout->grid2, SIGNAL(clicked()), SLOT(selectGrid(QGraphicsView*)));
//    connect(customLayout->grid3, SIGNAL(clicked()), SLOT(selectGrid(QGraphicsView*)));
//    connect(customLayout->grid4, SIGNAL(clicked()), SLOT(selectGrid(QGraphicsView*)));

    //connect(customLayout->grid2, SIGNAL(sigMouseClicked(QListWidgetItem*)), SLOT(selectItem(QListWidgetItem*)));


    loadImages();                                   // listWidget에 이미지 로드
    patientLoad();                                  // 환자 정보 DB 함수

    /* WindowTitle 지정 */
    customLayout = new Layout(this);
    customLayout->setWindowTitle(tr("2 X 2 Grid"));
    connect(customLayout, SIGNAL(destroyed()), customLayout, SLOT(deleteLater()));

    fmx = new FMX(this);
    fmx->setWindowTitle(tr("14 FMX"));
    connect(fmx, SIGNAL(destroyed()), fmx, SLOT(deleteLater()));


    QMdiSubWindow *cw = ui->mdiArea->addSubWindow(customLayout);
    ui->mdiArea->addSubWindow(fmx);
    //cw->setStyleSheet("background:rgb(32, 56, 100)");
    cw->setStyleSheet("background:rgb(0, 0, 0)");
    ui->mdiArea->setActiveSubWindow(cw);



}

MainWindow::~MainWindow()
{
    delete ui;
    QSqlDatabase clDB = QSqlDatabase::database("patientDB");            // 데이터베이스 닫기
    if(clDB.isOpen()){                                                  // 만약 파일이 열리면
        patientQueryModel->submitAll();
        delete patientQueryModel;
        clDB.close();
    }
}


void MainWindow::loadImages()
{
    QDir dir(".");
    QStringList filters;
    filters << "*.png" << "*.jpg" << "*.bmp";
    QFileInfoList fileInfoList = dir.entryInfoList(filters, QDir::Files | QDir::NoDotAndDotDot);
    //gridLayout->scene->clear();

    ui->listWidget->clear();
    for(int i=0; i<fileInfoList.count(); i++){
        QListWidgetItem* item = new QListWidgetItem(QIcon(fileInfoList.at(i).fileName()), NULL, ui->listWidget);
        item->setStatusTip(fileInfoList.at(i).fileName());
        ui->listWidget->addItem(item);
    };
}



//void MainWindow::selectItem(QListWidgetItem *item){
/////* 성공 */
////    static QGraphicsScene *beforeScene = NULL;              // static이 붙으면 지역변수여도 클래스 안에서 모두 쓸 수 있음.
////    if(beforeScene != NULL)
////        delete beforeScene;

////    QGraphicsScene *newScene = new QGraphicsScene;
////    beforeScene = newScene;
////    newScene->setBackgroundBrush(Qt::black);

////    customLayout->grid1->setScene(newScene);
////    newScene->addPixmap(QPixmap(item->statusTip()).scaledToHeight(customLayout->grid1->height()-2));
////    customLayout->grid1->setAlignment(Qt::AlignCenter);



//#if 1
///* 시도 - 성공 (with강사님) */
////    static QGraphicsScene *beforeScene1 = NULL;              // static이 붙으면 지역변수여도 클래스 안에서 모두 쓸 수 있음.
////    static QGraphicsScene *beforeScene2 = NULL;              // static이 붙으면 지역변수여도 클래스 안에서 모두 쓸 수 있음.
////    static QGraphicsScene *beforeScene3 = NULL;              // static이 붙으면 지역변수여도 클래스 안에서 모두 쓸 수 있음.
////    static QGraphicsScene *beforeScene4 = NULL;              // static이 붙으면 지역변수여도 클래스 안에서 모두 쓸 수 있음.
////    if(beforeScene1 != NULL)
////        delete beforeScene1;
////    if(beforeScene2 != NULL)
////        delete beforeScene2;
////    if(beforeScene3 != NULL)
////        delete beforeScene3;
////    if(beforeScene4 != NULL)
////        delete beforeScene4;

//    QGraphicsScene *newScene1 = new QGraphicsScene;
//    QGraphicsScene *newScene2 = new QGraphicsScene;
//    QGraphicsScene *newScene3 = new QGraphicsScene;
//    QGraphicsScene *newScene4 = new QGraphicsScene;

////    beforeScene1 = newScene1;
////    beforeScene2 = newScene2;
////    beforeScene3 = newScene3;
////    beforeScene4 = newScene4;

//    newScene1->setBackgroundBrush(Qt::black);
//    newScene2->setBackgroundBrush(Qt::black);
//    newScene3->setBackgroundBrush(Qt::black);
//    newScene4->setBackgroundBrush(Qt::black);

//    customLayout->grid1->setScene(newScene1);
//    customLayout->grid2->setScene(newScene2);
//    customLayout->grid3->setScene(newScene3);
//    customLayout->grid4->setScene(newScene4);

//    newScene1->update();
//    newScene2->update();
//    newScene3->update();
//    newScene4->update();

//    QSize size1 = customLayout->grid1->viewport()->size();
//    QSize size2 = customLayout->grid2->viewport()->size();
//    QSize size3 = customLayout->grid3->viewport()->size();
//    QSize size4 = customLayout->grid4->viewport()->size();

//    newScene1->addPixmap(QPixmap(item->statusTip()).scaled(size1, Qt::KeepAspectRatio));
//    newScene2->addPixmap(QPixmap(item->statusTip()).scaled(size2, Qt::KeepAspectRatio));
//    newScene3->addPixmap(QPixmap(item->statusTip()).scaled(size3, Qt::KeepAspectRatio));
//    newScene4->addPixmap(QPixmap(item->statusTip()).scaled(size4, Qt::KeepAspectRatio));


//    customLayout->grid1->setAlignment(Qt::AlignCenter);
//    customLayout->grid2->setAlignment(Qt::AlignCenter);
//    customLayout->grid3->setAlignment(Qt::AlignCenter);
//    customLayout->grid4->setAlignment(Qt::AlignCenter);
//#else               // scene이 겹쳐지는 문제 발생
//    customLayout->grid1->setScene(customLayout->scene1);
//    customLayout->grid2->setScene(customLayout->scene2);
//    customLayout->grid3->setScene(customLayout->scene3);
//    customLayout->grid4->setScene(customLayout->scene4);

//    QSize size1 = customLayout->grid1->viewport()->size();
//    QSize size2 = customLayout->grid2->viewport()->size();
//    QSize size3 = customLayout->grid3->viewport()->size();
//    QSize size4 = customLayout->grid4->viewport()->size();

//    customLayout->scene1->addPixmap(QPixmap(item->statusTip()).scaled(size1, Qt::KeepAspectRatio));
//    customLayout->scene2->addPixmap(QPixmap(item->statusTip()).scaled(size2, Qt::KeepAspectRatio));
//    customLayout->scene3->addPixmap(QPixmap(item->statusTip()).scaled(size3, Qt::KeepAspectRatio));
//    customLayout->scene4->addPixmap(QPixmap(item->statusTip()).scaled(size4, Qt::KeepAspectRatio));

//    customLayout->grid1->setAlignment(Qt::AlignCenter);
//    customLayout->grid2->setAlignment(Qt::AlignCenter);
//    customLayout->grid3->setAlignment(Qt::AlignCenter);
//    customLayout->grid4->setAlignment(Qt::AlignCenter);

//    customLayout->scene1->update();
//    customLayout->scene2->update();
//    customLayout->scene3->update();
//    customLayout->scene4->update();
//#endif

//     customLayoutLocation();                     // grid의 좌표값


//#if 0
//    //    if(newScene->sceneRect().width() > width1-x1) {
//    //        newScene->addPixmap(QPixmap(item->statusTip()).scaledToHeight(customLayout->grid1->width()-2));
//    //        newScene->addPixmap(QPixmap(item->statusTip()).scaledToHeight(customLayout->grid2->width()-2));
//    //        newScene->addPixmap(QPixmap(item->statusTip()).scaledToHeight(customLayout->grid3->width()-2));
//    //        newScene->addPixmap(QPixmap(item->statusTip()).scaledToHeight(customLayout->grid4->width()-2));
//    //    }

//    QPixmap pixmap = QPixmap(item->statusTip());
//    QGraphicsPixmapItem* pixMapItem1 = newScene1->addPixmap(pixmap.scaled(QSize(customLayout->grid1->sceneRect().size().width(),
//                                                                             customLayout->grid1->sceneRect().size().height()), Qt::KeepAspectRatio));
//    QGraphicsPixmapItem* pixMapItem2 = newScene2->addPixmap(pixmap.scaled(QSize(customLayout->grid1->sceneRect().size().width(),
//                                                                             customLayout->grid1->sceneRect().size().height()), Qt::KeepAspectRatio));
//    QGraphicsPixmapItem* pixMapItem3 = newScene3->addPixmap(pixmap.scaled(QSize(customLayout->grid1->sceneRect().size().width(),
//                                                                             customLayout->grid1->sceneRect().size().height()), Qt::KeepAspectRatio));
//    QGraphicsPixmapItem* pixMapItem4 = newScene4->addPixmap(pixmap.scaled(QSize(customLayout->grid1->sceneRect().size().width(),
//                                                                             customLayout->grid1->sceneRect().size().height()), Qt::KeepAspectRatio));

//    pixMapItem1->setFlag(QGraphicsItem::ItemIsMovable);

//    //pixMapItem->
////    pixMapItem->setPos(0,0);
//#endif
//}


void MainWindow::selectItem(QListWidgetItem *item)
{
#if 0
    QGraphicsScene *newScene1 = new QGraphicsScene;
    QGraphicsScene *newScene2 = new QGraphicsScene;
    QGraphicsScene *newScene3 = new QGraphicsScene;
    QGraphicsScene *newScene4 = new QGraphicsScene;

    newScene1->setBackgroundBrush(Qt::black);
    newScene2->setBackgroundBrush(Qt::black);
    newScene3->setBackgroundBrush(Qt::black);
    newScene4->setBackgroundBrush(Qt::black);

    customLayout->grid1->setScene(newScene1);
    customLayout->grid2->setScene(newScene2);
    customLayout->grid3->setScene(newScene3);
    customLayout->grid4->setScene(newScene4);

    newScene1->update();
    newScene2->update();
    newScene3->update();
    newScene4->update();

    QSize size1 = customLayout->grid1->viewport()->size();
    QSize size2 = customLayout->grid2->viewport()->size();
    QSize size3 = customLayout->grid3->viewport()->size();
    QSize size4 = customLayout->grid4->viewport()->size();

    newScene1->addPixmap(QPixmap(item->statusTip()).scaled(size1, Qt::KeepAspectRatio));
    newScene2->addPixmap(QPixmap(item->statusTip()).scaled(size2, Qt::KeepAspectRatio));
    newScene3->addPixmap(QPixmap(item->statusTip()).scaled(size3, Qt::KeepAspectRatio));
    newScene4->addPixmap(QPixmap(item->statusTip()).scaled(size4, Qt::KeepAspectRatio));


    customLayout->grid1->setAlignment(Qt::AlignCenter);
    customLayout->grid2->setAlignment(Qt::AlignCenter);
    customLayout->grid3->setAlignment(Qt::AlignCenter);
    customLayout->grid4->setAlignment(Qt::AlignCenter);

    customLayoutLocation();                     // grid의 좌표값

#else            // 시그널 grid, scene

    //    static QGraphicsScene *beforeScene = NULL;              // static이 붙으면 지역변수여도 클래스 안에서 모두 쓸 수 있음.
    //    if(beforeScene != NULL) {
    //        delete beforeScene;

    //    if(customLayout->grid1 != NULL) {
    //        newScene = new QGraphicsScene;
    //        newScene->setBackgroundBrush(Qt::black);
    //        customLayout->grid1->setScene(newScene);
    //        newScene->update();
    //        QSize size1 = customLayout->grid->viewport()->size();
    //        newScene->addPixmap(QPixmap(item->statusTip()).scaled(size1, Qt::KeepAspectRatio));
    //        customLayout->grid1->setAlignment(Qt::AlignCenter);

    //        customLayout->grid2->setScene(newScene);
    //        newScene->update();
    //        QSize size2 = customLayout->grid->viewport()->size();
    //        newScene->addPixmap(QPixmap(item->statusTip()).scaled(size2, Qt::KeepAspectRatio));
    //        customLayout->grid2->setAlignment(Qt::AlignCenter);

    //        customLayout->grid3->setScene(newScene);
    //        newScene->update();
    //        QSize size3 = customLayout->grid->viewport()->size();
    //        newScene->addPixmap(QPixmap(item->statusTip()).scaled(size3, Qt::KeepAspectRatio));
    //        customLayout->grid3->setAlignment(Qt::AlignCenter);

    //        customLayout->grid4->setScene(newScene);
    //        newScene->update();
    //        QSize size4 = customLayout->grid->viewport()->size();
    //        newScene->addPixmap(QPixmap(item->statusTip()).scaled(size4, Qt::KeepAspectRatio));
    //        customLayout->grid4->setAlignment(Qt::AlignCenter);
    //    }

//    qDebug() << "Test";

//    if(customLayout->g == false) {
//        if(cnt == 0) {
//            newScene1 = new QGraphicsScene;
//            newScene1->setBackgroundBrush(Qt::black);
//            customLayout->grid1->setScene(newScene1);
//            QSize size = customLayout->grid1->viewport()->size();
//            newScene1->addPixmap(QPixmap(item->statusTip()).scaled(size, Qt::KeepAspectRatio));
//            customLayout->grid1->setAlignment(Qt::AlignCenter);

//            cnt++;
//            qDebug() << "click : 1";
//        }
//        else if(cnt == 1) {
//            newScene2 = new QGraphicsScene;
//            newScene2->setBackgroundBrush(Qt::black);
//            customLayout->grid2->setScene(newScene2);
//            QSize size = customLayout->grid2->viewport()->size();
//            newScene2->addPixmap(QPixmap(item->statusTip()).scaled(size, Qt::KeepAspectRatio));
//            customLayout->grid2->setAlignment(Qt::AlignCenter);
//            cnt++;

//            qDebug() << "click : 2";
//        }
//        else if(cnt == 2) {
//            newScene3 = new QGraphicsScene;
//            newScene3->setBackgroundBrush(Qt::black);
//            customLayout->grid3->setScene(newScene3);
//            QSize size = customLayout->grid3->viewport()->size();
//            newScene3->addPixmap(QPixmap(item->statusTip()).scaled(size, Qt::KeepAspectRatio));
//            customLayout->grid3->setAlignment(Qt::AlignCenter);

//            cnt++;
//            qDebug() << "click : 3";
//        }
//        else if(cnt == 3) {
//            newScene4 = new QGraphicsScene;
//            newScene4->setBackgroundBrush(Qt::black);
//            customLayout->grid4->setScene(newScene4);
//            QSize size = customLayout->grid4->viewport()->size();
//            newScene4->addPixmap(QPixmap(item->statusTip()).scaled(size, Qt::KeepAspectRatio));
//            customLayout->grid4->setAlignment(Qt::AlignCenter);

//            cnt++;
//            qDebug() << "click : 4";
//        }
//    }

//    else if(customLayout->g == true) {
//        //----------------------------------------------------------------------

//        newScene = new QGraphicsScene;
//        newScene->setBackgroundBrush(Qt::black);
//        customLayout->grid->setScene(newScene);
//        newScene->update();
//        QSize size = customLayout->grid->viewport()->size();
//        newScene->addPixmap(QPixmap(item->statusTip()).scaled(size, Qt::KeepAspectRatio));
//        customLayout->grid->setAlignment(Qt::AlignCenter);

//        //----------------------------------------------------------------------
//    }
//    //    customLayoutLocation();

#endif

// 다시 시도

    qDebug() << "Test";

    if(customLayout->g == false) {
        if(cnt == 0) {
            customLayout->scene1->clear();
            customLayout->grid1->setScene(customLayout->scene1);
            QSize size = customLayout->grid1->viewport()->size();
            customLayout->scene1->addPixmap(QPixmap(item->statusTip()).scaled(size, Qt::KeepAspectRatio));
            customLayout->grid1->setAlignment(Qt::AlignCenter);

            cnt++;
            qDebug() << "click : 1";
        }
        else if(cnt == 1) {
            customLayout->scene2->clear();
            customLayout->grid2->setScene(customLayout->scene2);
            QSize size = customLayout->grid2->viewport()->size();
            customLayout->scene2->addPixmap(QPixmap(item->statusTip()).scaled(size, Qt::KeepAspectRatio));
            customLayout->grid2->setAlignment(Qt::AlignCenter);
            cnt++;

            qDebug() << "click : 2";
        }
        else if(cnt == 2) {
            customLayout->scene3->clear();
            customLayout->grid3->setScene(customLayout->scene3);
            QSize size = customLayout->grid3->viewport()->size();
            customLayout->scene3->addPixmap(QPixmap(item->statusTip()).scaled(size, Qt::KeepAspectRatio));
            customLayout->grid3->setAlignment(Qt::AlignCenter);

            cnt++;
            qDebug() << "click : 3";
        }
        else if(cnt == 3) {
            customLayout->scene4->clear();
            customLayout->grid4->setScene(customLayout->scene4);;
            QSize size = customLayout->grid4->viewport()->size();
            customLayout->scene4->addPixmap(QPixmap(item->statusTip()).scaled(size, Qt::KeepAspectRatio));
            customLayout->grid4->setAlignment(Qt::AlignCenter);

            cnt++;
            qDebug() << "click : 4";
        }
    }

    else if(customLayout->g == true) {
        //----------------------------------------------------------------------

        newScene = new QGraphicsScene;
        newScene->setBackgroundBrush(Qt::black);
        customLayout->grid->setScene(newScene);
        newScene->update();
        QSize size = customLayout->grid->viewport()->size();
        newScene->addPixmap(QPixmap(item->statusTip()).scaled(size, Qt::KeepAspectRatio));
        customLayout->grid->setAlignment(Qt::AlignCenter);

        //----------------------------------------------------------------------
    }

    else if(customLayout->n == true) {

        QSize size = customLayout->newView->viewport()->size();
        customLayout->newScene->addPixmap(QPixmap(item->statusTip()).scaled(size, Qt::KeepAspectRatio));
        customLayout->newView->setAlignment(Qt::AlignCenter);
    }
}

/* 사용안함 */
void MainWindow::newWindow()
{
//    customLayout->n = true;

//    QSize size = customLayout->grid->viewport()->size();
//    newScene->addPixmap(QPixmap(item->statusTip()).scaled(size, Qt::KeepAspectRatio));
//    customLayout->grid->setAlignment(Qt::AlignCenter);

}




void MainWindow::on_imageClearPushButton_clicked()                  // scene 이미지 초기화
{
    customLayout->grid1->scene()->clear();
    customLayout->grid2->scene()->clear();
    customLayout->grid3->scene()->clear();
    customLayout->grid4->scene()->clear();

    cnt = 0;

//    customLayout->grid1->setStyleSheet("border: 0.5px solid rgb(129, 134, 143)");
//    customLayout->grid2->setStyleSheet("border: 0.5px solid rgb(129, 134, 143)");
//    customLayout->grid3->setStyleSheet("border: 0.5px solid rgb(129, 134, 143)");
//    customLayout->grid4->setStyleSheet("border: 0.5px solid rgb(129, 134, 143)");

//    customLayout->scene1->setBackgroundBrush(Qt::black);
//    customLayout->scene2->setBackgroundBrush(Qt::black);
//    customLayout->scene3->setBackgroundBrush(Qt::black);
//    customLayout->scene4->setBackgroundBrush(Qt::black);

    customLayout->g = false;
}


/* 환자 정보 DB */
void MainWindow::patientLoad()
{
    //QSQLITE 파일로 데이터 베이스 생성                  //데이터베이스가 2개 이상 사용으로 이름 설정
    QSqlDatabase DB = QSqlDatabase::addDatabase("QSQLITE");
    DB.setDatabaseName("patientDB.db");                             //데이터베이스 이름설정

    if(DB.open()){                                                 //조건문
        patientQuery = new QSqlQuery(DB);
        //query 문을 이용하여 테이블 생성 및 PK 키 설정
        patientQuery->exec("CREATE TABLE IF NOT EXISTS patient(chartNum INTEGER Primary Key,"
                           "name VARCHAR(20) NOT NULL, age INTEGER,imagePath VARCHAR(20));");

        patientQueryModel = new QSqlTableModel(this, DB);
        patientQueryModel->setTable("patient");
        patientQueryModel->select();

        /*테이블 헤더 설정*/
        patientQueryModel->setHeaderData(0, Qt::Horizontal, QObject::tr("ChartNum"));
        patientQueryModel->setHeaderData(1, Qt::Horizontal, QObject::tr("Name"));
        patientQueryModel->setHeaderData(2, Qt::Horizontal, QObject::tr("Age"));
        patientQueryModel->setHeaderData(3, Qt::Horizontal, QObject::tr("ImagePath"));

        ui->patientTableView->setModel(patientQueryModel);

        ui->patientTableView->hideColumn(3);

        patientQuery->exec("INSERT INTO patient VALUES (1000,'JaeYeong','28','..')");
        patientQuery->exec("INSERT INTO patient VALUES (1001,'Yuna','26','..')");
        patientQuery->exec("INSERT INTO patient VALUES (1002,'Jaehyun','27','..')");
        patientQuery->exec("INSERT INTO patient VALUES (1003,'eunji','29','..')");
        patientQuery->exec("INSERT INTO patient VALUES (1004,'chelly','28','..')");
        patientQuery->exec("INSERT INTO patient VALUES (1005,'brian','26','..')");
        patientQuery->exec("INSERT INTO patient VALUES (1006,'dessery','27','..')");
        patientQuery->exec("INSERT INTO patient VALUES (1007,'eclipse','29','..')");
        patientQueryModel->select();
        ui->patientTableView->resizeColumnsToContents();
    }
}

/* ui 색상 및 크기 조절 */
void MainWindow::styleColor()
{
    ui->mdiArea->setStyleSheet("background:rgb(32, 56, 100)");
    ui->splitter->setStyleSheet("background:rgb(32, 56, 100)");
    ui->splitter2->setStyleSheet("background:rgb(32, 56, 100)");
    ui->splitter3->setStyleSheet("background:rgb(32, 56, 100)");
    ui->splitter4->setStyleSheet("background:rgb(32, 56, 100)");
    ui->treeWidget1->setStyleSheet("background:rgb(255, 255, 255)");
    ui->treeWidget2->setStyleSheet("background:rgb(255, 255, 255)");
    ui->listWidget->setStyleSheet("background:rgb(255, 255, 255)");
    ui->patientTableView->setStyleSheet("background:rgb(255, 255, 255)");
    ui->doctorNameLineEdit->setStyleSheet("background:rgb(180, 199, 231)");
    //ui->line->setStyleSheet("background:rgb(255, 255, 255)");
    ui->line->setStyleSheet(sheetWhite);


    /* Painter */
    ui->tabWidget->setStyleSheet(sheetNavy);
    ui->brushToolButton->setStyleSheet(sheetWhite);
    ui->spinBox->setStyleSheet(sheetWhite);;
    ui->circleToolButton->setStyleSheet(sheetWhite);
    ui->triangleToolButton->setStyleSheet(sheetWhite);
    ui->rectangleToolButton->setStyleSheet(sheetWhite);
    ui->arrowToolButton->setStyleSheet(sheetWhite);
    ui->colorToolButton->setStyleSheet(sheetWhite);

    /* Processing */
    ui->brightToolButton->setStyleSheet(sheetWhite);
    ui->brightnessToolButton->setStyleSheet(sheetWhite);
    ui->sharpenToolButton->setStyleSheet(sheetWhite);
    ui->contrastToolButton->setStyleSheet(sheetWhite);
    ui->horizontalFlipToolButton->setStyleSheet(sheetWhite);
    ui->verticalFlipToolButton->setStyleSheet(sheetWhite);
    ui->zoomInToolButton->setStyleSheet(sheetWhite);
    ui->zoomOutToolButton->setStyleSheet(sheetWhite);
    ui->panningToolButton->setStyleSheet(sheetWhite);
    ui->leftRotateToolButton->setStyleSheet(sheetWhite);
    ui->rightRotateToolButton->setStyleSheet(sheetWhite);

    /* Measure */
    ui->rulerToolButton->setStyleSheet(sheetWhite);
    ui->measureToolButton->setStyleSheet(sheetWhite);
    ui->protractorToolButton->setStyleSheet(sheetWhite);
    ui->implantToolButton->setStyleSheet(sheetWhite);
    ui->implantToolButton_2->setStyleSheet(sheetWhite);

   // ui->toolBar->setToolButtonStyle(Qt::ToolBarArea));

    QList<int> sizes;
    sizes << 10 << 1000;
    ui->splitter->setSizes(sizes);

    QList<int> sizes2;
    sizes2 << 700 << 100;
    ui->splitter2->setSizes(sizes2);

    QList<int> sizes3;
    sizes3 << 10 << 2000;
    ui->splitter3->setSizes(sizes3);

    QList<int> sizes4;
    sizes4 << Qt::MaximumSize << Qt::MinimumSize;
    ui->splitter4->setSizes(sizes4);


    ui->verticalSpacer->changeSize(20, 15);
    ui->verticalSpacer_2->changeSize(20, 40);
    ui->verticalSpacer_3->changeSize(20, 20);
    ui->verticalSpacer_4->changeSize(20, 20);
    ui->horizontalSpacer_8->changeSize(20, 12);
    ui->horizontalSpacer_9->changeSize(10,10);
    ui->horizontalSpacer_10->changeSize(10,10);
    ui->verticalSpacer_5->changeSize(12, 30);

    /* toolButton 크기 조절 */
    ui->brushToolButton->setIconSize(QSize(50,40));
    ui->brushToolButton->setText("Brush");
    ui->brushToolButton->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);

    ui->colorToolButton->setIconSize(QSize(100,30));
    ui->colorToolButton->setText("Color");
    ui->colorToolButton->setToolButtonStyle(Qt::ToolButtonTextBesideIcon);


}


void MainWindow::customLayoutLocation()
{
    /* grid1(graphicsView) 의 좌표값 */
    int x1 = customLayout->grid1->pos().x();                 // grid1의 topLeft의 x 좌표값
    int y1 = customLayout->grid1->pos().y();                 // grid1의 topLeft의 y 좌표값
    int width1 = x1 + customLayout->grid1->width();          // grid1의 topLeft의 x좌표값에서 grid의 폭만큼 이동한 x의 좌표값
    int height1 = y1 + customLayout->grid1->height();        // grid1의 topLeft의 y 좌표값에서 grid의 높이만큼 이동한 y의 좌표값

    /* grid2(graphicsView) 의 좌표값 */
    int x2 = customLayout->grid2->pos().x();
    int y2 = customLayout->grid2->pos().y();
    int width2 = x2 + customLayout->grid2->width();
    int height2 = y2 + customLayout->grid2->height();

    /* grid3(graphicsView) 의 좌표값 */
    int x3 = customLayout->grid3->pos().x();
    int y3 = customLayout->grid3->pos().y();
    int width3 = x3 + customLayout->grid3->width();
    int height3 = y3 + customLayout->grid3->height();

    /* grid4(graphicsView) 의 좌표값 */
    int x4 = customLayout->grid4->pos().x();
    int y4 = customLayout->grid4->pos().y();
    int width4 = x4 + customLayout->grid4->width();
    int height4 = y4 + customLayout->grid4->height();

    qDebug("grid1의 TopLeft : (%d, %d)", x1, y1);
    qDebug("grid1의 TopRight : (%d, %d)", width1, y1);
    qDebug("grid1의 ButtomLeft : (%d, %d)", x1, height1);
    qDebug("grid1의 ButtomRight : (%d, %d)\n", width1, height1);

    qDebug("grid2의 TopLeft : (%d, %d)", x2, y2);
    qDebug("grid2의 TopRight : (%d, %d)", width2, y2);
    qDebug("grid2의 ButtomLeft : (%d, %d)", x2, height2);
    qDebug("grid2의 ButtomRight : (%d, %d)\n", width2, height2);

    qDebug("grid3의 TopLeft : (%d, %d)", x3, y3);
    qDebug("grid3의 TopRight : (%d, %d)", width3, y3);
    qDebug("grid3의 ButtomLeft : (%d, %d)", x3, height3);
    qDebug("grid3의 ButtomRight : (%d, %d)\n", width3, height3);

    qDebug("grid4의 TopLeft : (%d, %d)", x4, y4);
    qDebug("grid4의 TopRight : (%d, %d)", width4, y4);
    qDebug("grid4의 ButtomLeft : (%d, %d)", x4, height4);
    qDebug("grid4의 ButtomRight : (%d, %d)\n", width4, height4);

//    qDebug() << x1;
//    qDebug() << y1;
//    qDebug() << width1;
//    qDebug() << height1;
//    qDebug("\n");
}





