#ifndef LAYOUT_H
#define LAYOUT_H


#include <QWidget>

class QGraphicsView;
class QGraphicsScene;

class QHoverEvent;
class QEvent;

class MainWindow;

class Layout : public QWidget
{
    Q_OBJECT
public:
    explicit Layout(QWidget *parent = nullptr);

    QGraphicsView *grid1;
    QGraphicsView *grid2;
    QGraphicsView *grid3;
    QGraphicsView *grid4;

    QGraphicsScene *scene1;
    QGraphicsScene *scene2;
    QGraphicsScene *scene3;
    QGraphicsScene *scene4;

    QGraphicsView *grid;
    QGraphicsScene *scene;

    QGraphicsView *newView;
    QGraphicsScene *newScene;

    QPointF clickPoint;
    QWidget *widget;


//    NewWindow *newWindow;

    bool g = false;
    bool n = false;




protected:
    void mousePressEvent(QMouseEvent *event) override;
    void mouseDoubleClickEvent(QMouseEvent *event) override;


private:
    void gridLayout();


signals:
    void sig_layoutInfo(QGraphicsView* grid, QGraphicsScene* scene);
//    void sig_layoutInfo2(QGraphicsView* grid2, QGraphicsScene* scene2);
//    void sig_layoutInfo3(QGraphicsView* grid3, QGraphicsScene* scene3);
//    void sig_layoutInfo4(QGraphicsView* grid4, QGraphicsScene* scene4);


public slots:


};

#endif // LAYOUT_H
