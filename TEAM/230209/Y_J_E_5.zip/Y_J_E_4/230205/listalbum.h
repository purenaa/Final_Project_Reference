//#ifndef LISTALBUM_H
//#define LISTALBUM_H

//#include "qlistwidget.h"

//#include <QWidget>
//#include <QSplitter>

//class QListWidget;


//class Listalbum : public QSplitter
//{
//    Q_OBJECT
//public:
//    explicit Listalbum(QWidget *parent = nullptr);

//    void loadImages();


//private:
//    QListWidget *listWidget;

//private slots:


//signals:

//};

//#endif // LISTALBUM_H
