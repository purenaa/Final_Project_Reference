#include "scene.h"

#include <QGraphicsScene>
#include <QGraphicsSceneMouseEvent>
#include <QCursor>
#include <QGraphicsItem>
#include <QPixmap>
#include <cmath>
#include <QVector2D>


#define ItemWidth   4


Scene::Scene(QObject *parent)
    : QGraphicsScene{parent}
{
    m_currentItem = nullptr;
    m_currentShape = Cursor;
    m_isClicked = false;
    m_imCount = 1;

}

void Scene::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    if(m_currentShape == Implant){
        if(m_imCount == 1){
            m_prevPos = event->scenePos();      // m_prevPos : 첫 번째 좌표값 (Top Left)
            m_imCount++;

            /* 클릭했을 때 좌표 점 찍기 (빨간점) */
            QBrush brush(QColor(Qt::red), Qt::SolidPattern);
            QGraphicsEllipseItem* item1 = new QGraphicsEllipseItem();
            item1->setBrush(brush);
            item1->setRect(0, 0, ItemWidth, ItemWidth);
            item1->setPos(m_prevPos);
            addItem(item1);
            m_point.append(item1);
        }

        else if(m_imCount == 2) {
            m_latePos = event->scenePos();      // m_latePos : 두 번째 좌표값 (Bottom Left)
            m_imCount++;

            /* 클릭했을 때 좌표 점 찍기 (파란점) */
            QBrush brush(QColor(Qt::blue), Qt::SolidPattern);
            QGraphicsEllipseItem* item2 = new QGraphicsEllipseItem();
            item2->setBrush(brush);
            item2->setRect(0, 0, ItemWidth, ItemWidth);
            item2->setPos(m_latePos);
            addItem(item2);
            m_point.append(item2);
        }

        else if(m_imCount == 3) {
            m_sPos = event->scenePos();      // m_sPos : 세 번째 좌표값 (Right의 임의의 한 점의 좌표값 = width의 역할)
            addImplantItem(m_prevPos, m_latePos, m_sPos);
            m_imCount = 1;
            m_currentShape = Cursor;          // 1개의 임플란트만 나오게 설정하는 부분

            /* 클릭했을 때 좌표 점 찍기 (노란점) */
            QBrush brush(QColor(Qt::yellow), Qt::SolidPattern);
            QGraphicsEllipseItem* item3 = new QGraphicsEllipseItem();
            item3->setBrush(brush);
            item3->setRect(0, 0, ItemWidth, ItemWidth);
            item3->setPos(m_sPos);
            addItem(item3);
            m_point.append(item3);
        }
    }
    QGraphicsScene::mousePressEvent(event);
}


void Scene::mouseMoveEvent(QGraphicsSceneMouseEvent *event)
{
    /* 선택된 아이템 이동 */
    foreach(auto item, selectedItems())
        item->setFlags(QGraphicsItem::ItemIsMovable| QGraphicsItem::ItemIsSelectable);
    update();

    QGraphicsScene::mouseMoveEvent(event);
}


void Scene::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
    if(m_currentItem != nullptr)
        delete m_currentItem;

    switch(m_currentShape){

    case Cursor:
        break;

    case Implant:
        break;
    }
    m_currentItem = nullptr;
    QGraphicsScene::mouseReleaseEvent(event);
}


void Scene::addImplantItem(QPointF stPos, QPointF edPos, QPointF mPos)
{
//    int height = sqrt(pow(edPos.x() - stPos.x(), 2) + pow(edPos.y() - edPos.y(), 2));
//    int width = sqrt(pow(mPos.x()-stPos.x(), 2) + pow(mPos.y() - edPos.y(), 2));
//    QSizeF size(width, height);

    qDebug() << stPos;          // 첫 번째 좌표
    qDebug() << edPos;          // 두 번째 좌표
    qDebug() << mPos;           // 세 번째 좌표

    int xPos = (edPos.x() + stPos.x())/2;
    int yPos = (edPos.y() + stPos.y())/2;

    int line = sqrt(pow(xPos - mPos.x(), 2) + pow(yPos - mPos.y(), 2));

    QVector2D dot1(stPos);
    QVector2D dot2(edPos);
//    QVector2D dot3(mPos);

    float distance1 = dot1.distanceToPoint(dot2);
//    float distance2 = dot1.distanceToPoint(dot3);

    QSizeF size(line, distance1);
    QRectF rect(stPos, size);

    qDebug() << distance1;
//    qDebug() << distance2;
    qDebug() << line;


//    double angle = atan2((stPos.y()-edPos.y()), (stPos.x()-edPos.x()));

#if 0
    /* 시그널 슬롯을 사용하지 않고 이미지 경로로 바로 접근해서 잘 되는 경우 */
    QString imagePath(tr(":/teeth/teeth/topLeft/11.png"));
    QPixmap teeth11(imagePath);
    pixmapItem = new QGraphicsPixmapItem(teeth11.scaled(rect.normalized().size().toSize(), Qt::IgnoreAspectRatio));
#else

        qDebug() << "addImplantItem의 중간 위치" << showTeeth;
        QGraphicsPixmapItem* pixmapItem = new QGraphicsPixmapItem(showTeeth->scaled(rect.normalized().size().toSize(), Qt::IgnoreAspectRatio));
#endif

    pixmapItem->setFlags(QGraphicsItem::ItemIsSelectable);
    pixmapItem->setPos(stPos);

//    double angle = atan2(rect.y(), rect.x());
//    double angle = atan2((stPos.y()-edPos.y()), (stPos.x()-edPos.x()));

//    double angleRadian = atan((edPos.y() - stPos.y()) / (edPos.x() - stPos.x()));


    double angleRadian = atan2((stPos.x()-edPos.x()), (stPos.y()-edPos.y()));
    double angleDegree = floor(qRadiansToDegrees(angleRadian));
    pixmapItem->setRotation(180 - angleDegree);


//    if(mPos.x() > edPos.x()) {
//        pixmapItem->setRotation(180 - angleDegree);
//    }
//    else if(mPos.x() < edPos.x()) {
//        pixmapItem->setRotation(angleDegree - 180);
//    }

    qDebug() << angleRadian;
    qDebug() << angleDegree;

    addItem(pixmapItem);

    m_implantItems.append(pixmapItem);
    qDebug() << m_implantItems.size();

    qDebug() << "addImplantItem의 showTeeth" << showTeeth;
}




void Scene::setCurrentShape(const Shape &value)
{
    m_currentShape = value;
}

void Scene::clearItems()
{
    foreach(auto items, m_implantItems)
        removeItem(items);

    foreach(auto pointitem, m_point)
        removeItem(pointitem);

    m_imCount = 1;              // 삭제할 때 좌표(순서 점) 초기화
}


/* Top Left Teeth */
void Scene::slot_11(QPixmap* teeth11)
{
    qDebug() << "치아 11번 슬롯이 동작합니다.";

    showTeeth = teeth11;        // 11번 임플란트 이미지
}

void Scene::slot_12(QPixmap* teeth12)
{
    showTeeth = teeth12;        // 12번 임플란트 이미지
}

void Scene::slot_13(QPixmap* teeth13)
{
    showTeeth = teeth13;        // 13번 임플란트 이미지
}

void Scene::slot_14(QPixmap* teeth14)
{
    showTeeth = teeth14;        // 14번 임플란트 이미지
}

void Scene::slot_15(QPixmap* teeth15)
{
    showTeeth = teeth15;        // 15번 임플란트 이미지
}

void Scene::slot_16(QPixmap* teeth16)
{
    showTeeth = teeth16;        // 16번 임플란트 이미지
}

void Scene::slot_17(QPixmap* teeth17)
{
    showTeeth = teeth17;        // 17번 임플란트 이미지
}


/* Top Right Teeth */
void Scene::slot_21(QPixmap* teeth21)
{
    showTeeth = teeth21;        // 21번 임플란트 이미지
}
void Scene::slot_22(QPixmap* teeth22)
{
    showTeeth = teeth22;        // 22번 임플란트 이미지
}
void Scene::slot_23(QPixmap* teeth23)
{
    showTeeth = teeth23;        // 23번 임플란트 이미지
}
void Scene::slot_24(QPixmap* teeth24)
{
    showTeeth = teeth24;        // 24번 임플란트 이미지
}
void Scene::slot_25(QPixmap* teeth25)
{
    showTeeth = teeth25;        // 25번 임플란트 이미지
}
void Scene::slot_26(QPixmap* teeth26)
{
    showTeeth = teeth26;        // 26번 임플란트 이미지
}
void Scene::slot_27(QPixmap* teeth27)
{
    showTeeth = teeth27;        // 27번 임플란트 이미지
}


/* Top Right Teeth */
void Scene::slot_31(QPixmap* teeth31)
{
    showTeeth = teeth31;        // 31번 임플란트 이미지
}
void Scene::slot_32(QPixmap* teeth32)
{
    showTeeth = teeth32;        // 32번 임플란트 이미지
}
void Scene::slot_33(QPixmap* teeth33)
{
    showTeeth = teeth33;        // 33번 임플란트 이미지
}
void Scene::slot_34(QPixmap* teeth34)
{
    showTeeth = teeth34;        // 34번 임플란트 이미지
}
void Scene::slot_35(QPixmap* teeth35)
{
    showTeeth = teeth35;        // 35번 임플란트 이미지
}
void Scene::slot_36(QPixmap* teeth36)
{
    showTeeth = teeth36;        // 36번 임플란트 이미지
}
void Scene::slot_37(QPixmap* teeth37)
{
    showTeeth = teeth37;        // 37번 임플란트 이미지
}


/* Bottom Left Teeth */
void Scene::slot_41(QPixmap* teeth41)
{
    showTeeth = teeth41;        // 41번 임플란트 이미지
}
void Scene::slot_42(QPixmap* teeth42)
{
    showTeeth = teeth42;        // 42번 임플란트 이미지
}
void Scene::slot_43(QPixmap* teeth43)
{
    showTeeth = teeth43;        // 43번 임플란트 이미지
}
void Scene::slot_44(QPixmap* teeth44)
{
    showTeeth = teeth44;        // 44번 임플란트 이미지
}
void Scene::slot_45(QPixmap* teeth45)
{
    showTeeth = teeth45;        // 45번 임플란트 이미지
}
void Scene::slot_46(QPixmap* teeth46)
{
    showTeeth = teeth46;        // 46번 임플란트 이미지
}
void Scene::slot_47(QPixmap* teeth47)
{
    showTeeth = teeth47;        // 47번 임플란트 이미지
}




/* 패닝 */
//void Scene::mousePressEvent(QGraphicsSceneMouseEvent *event) {
////    if (event->button() == Qt::RightButton)
////    {
////        _pan = true;
////        _panStartX = event->pos().x();
////        _panStartY = event->pos().y();
//////        setCursor(Qt::ArrowCursor);
////        event->accept();
////        return;
////        qDebug() << "오른쪽 패닝 클릭";
////    }
////    event->ignore();
//    qDebug() << "오른쪽 패닝 클릭";
//}

//void Scene::mouseReleaseEvent(QGraphicsSceneMouseEvent *event) {
////    if (event->button() == Qt::RightButton)
////    {
////        _pan = false;
//////        setCursor(Qt::ArrowCursor);
////        event->accept();
////        return;
////        qDebug() << "오른쪽 패닝 뗌";
////    }
////    event->ignore();
//    qDebug() << "오른쪽 패닝 뗌";
//}

//void Scene::mouseMoveEvent(QGraphicsSceneMouseEvent *event) {
//    emit sig_move(event);
//}
