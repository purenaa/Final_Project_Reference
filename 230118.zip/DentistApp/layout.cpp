#include "layout.h"

#include <QGridLayout>
#include <QGraphicsView>

#include <QPixmap>
#include <QMouseEvent>
#include <QMessageBox>


Layout::Layout(QWidget *parent)
    : QWidget{parent}
{
    gridLayout();

    scene1 = new QGraphicsScene;
    scene1->setBackgroundBrush(Qt::black);
    scene2 = new QGraphicsScene;
    scene2->setBackgroundBrush(Qt::black);
    scene3 = new QGraphicsScene;
    scene3->setBackgroundBrush(Qt::black);
    scene4 = new QGraphicsScene;
    scene4->setBackgroundBrush(Qt::black);

    grid1->setScene(scene1);
    grid2->setScene(scene2);
    grid3->setScene(scene3);
    grid4->setScene(scene4);
}

/* 2 X 2 Grid */
void Layout::gridLayout()
{
    grid1 = new QGraphicsView;
    grid2 = new QGraphicsView;
    grid3 = new QGraphicsView;
    grid4 = new QGraphicsView;

    QHBoxLayout *lay1 = new QHBoxLayout;
    lay1->addWidget(grid1);
    lay1->addSpacing(5);
    lay1->addWidget(grid2);

    QHBoxLayout *lay2 = new QHBoxLayout;
    lay2->addWidget(grid3);
    lay2->addSpacing(5);
    lay2->addWidget(grid4);

    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->addLayout(lay1);
    layout->addSpacing(5);
    layout->addLayout(lay2);
}

void Layout::mousePressEvent(QMouseEvent *event)
{
    qDebug() << "Mouse Pressed" << event->pos();

    if(event->button() == Qt::LeftButton) {
        QPointF clickPoint = event->pos();

        if((clickPoint.x() >= 9 && clickPoint.x() <= 382) && (clickPoint.y() >= 9 && clickPoint.y() <= 198)) {
            //grid1->setScene(scene1);
            grid = grid1;
            scene = scene1;
            qDebug("scene1 clicked 1");
        }

        if((clickPoint.x() >= 393 && clickPoint.x() <= 765) && (clickPoint.y() >= 9 && clickPoint.y() <= 198)) {
            //grid2->setScene(scene2);
            grid = grid2;
            scene = scene2;
            qDebug("scene2 clicked 2");
        }

        if((clickPoint.x() >= 9 && clickPoint.x() <= 382) && (clickPoint.y() >= 209 && clickPoint.y() <= 398)) {
            //grid3->setScene(scene3);
            grid = grid3;
            scene = scene3;
            qDebug("scene3 clicked 3");
        }

        if((clickPoint.x() >= 393 && clickPoint.x() <= 765) && (clickPoint.y() >= 209 && clickPoint.y() <= 398)) {
            //grid4->setScene(scene4);
            grid = grid4;
            scene = scene4;
            qDebug("scene4 clicked 4");
        }
//        emit sig_layoutInfo(grid, scene);
        qDebug("시그널");
    }

}




//void FramelessResize::DragResize(QEvent *ev)
//{
////    QHoverEvent* e = (QHoverEvent*)ev;
////    QMargins offset;
////    if(_pressDirection & LEFT)
////        offset.setLeft((e->oldPos() - e->pos()).x());
////    if(_pressDirection & RIGHT)
////        offset.setRight((e->pos() - e->oldPos() ).x());
////    if(_pressDirection & TOP)
////        offset.setTop((e->oldPos() - e->pos()).y());
////    if(_pressDirection & BOTTOM)
////        offset.setBottom((e->pos() - e->oldPos() ).y());

////    emit OffsetGeometry(offset);
//}




