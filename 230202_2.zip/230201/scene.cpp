#include "scene.h"


Scene::Scene(QObject *parent)
    : QGraphicsScene{parent}
{

}

