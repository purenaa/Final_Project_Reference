#ifndef SCENE_H
#define SCENE_H

#include <QGraphicsScene>
#include <QHash>

class TeethForm;
class QMouseEvent;




class Scene : public QGraphicsScene
{
    Q_OBJECT
public:
    explicit Scene(QObject *parent = nullptr);

    bool _pan;
    int _panStartX, _panStartY;

    enum Shape {Cursor, Implant, Line, Rect, Ellipse, Path, Arrow, Triangle, Text};

    void setCurrentShape(const Shape &value);

    //void addImplantItem(QPointF stPos, QPointF edPos);          // 마우스 위치에 임플란트 이미지를 출력하는 함수
    void addImplantItem(QPointF stPos, QPointF edPos, QPointF mPos);


//    QHash<QGraphicsPixmapItem*, QString> implantHash;
//    QGraphicsPixmapItem* pixmapItem;

/* EUN JI */
// ----------------------------------------

//    Shape getCurrentShape() const;

    QColor getCurrentColor() const;
    void setCurrentColor(const QColor& color);

    qreal rotation() const;
    void setRotation(qreal angle);

    void setText(QString string);

// ----------------------------------------


    // List
    QList<QGraphicsPathItem*> m_pathList;
    QList<QGraphicsItem*> m_allitems;
    QList<QGraphicsItem*> m_implantItems;
    QList<QGraphicsItem*> m_point;

    bool ts = false;

protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event) override;
    void mouseMoveEvent(QGraphicsSceneMouseEvent *event) override;
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event) override;


    /* EUN JI */
    // ---------------------------------------------------
        void keyPressEvent(QKeyEvent *event) override;

        void addLineItem(QPointF stPos, QPointF edPos);
        void addRectItem(QPointF stPos, QPointF edPos);
        void addEllipseItem(QPointF stPos, QPointF edPos);
        void addImageItem(QPointF stPos, QPointF edPos);
        void addTriangleItem(QPointF stPos, QPointF midPos, QPointF edPos);
        void addArrowItem(QPointF stPos, QPointF edPos);
        void addTextItem(QPointF stPos);
    // ---------------------------------------------------


private:
    Shape m_currentShape;
    QGraphicsItem* m_currentItem;

    bool m_isClicked;
    QPointF m_prevPos;  // 이전 좌표값
    QPointF m_latePos;  // 이후 좌표값

    QPointF m_sPos;      // 세컨 좌표값

    int m_imCount;


    QPixmap* showTeeth;         // 슬롯으로 받은 치아 이미지를 담는 변수
    QString ipH;



/* EUN JI*/
//------------------------------------------------------------------
    bool drawing;
    bool drawEllipse = false;

    int m_triClicked;

    //PathItem
    QGraphicsPathItem* m_pathItem;

    QColor m_currentColor;
    QPointF m_startPos;
    QPointF m_midPos;

    qreal paintSize;        // 선의 크기를 기억하는 변수
    qreal rotateAngle;

    QString text;

//------------------------------------------------------------------



public slots:
    void clearItems();
    void implantClearItems();

    /* Top Left Teeth */
    void slot_11(QPixmap* teeth11);
    void slot_12(QPixmap* teeth12);
    void slot_13(QPixmap* teeth13);
    void slot_14(QPixmap* teeth14);
    void slot_15(QPixmap* teeth15);
    void slot_16(QPixmap* teeth16);
    void slot_17(QPixmap* teeth17);

     /* Top Right Teeth */
    void slot_21(QPixmap* teeth21);
    void slot_22(QPixmap* teeth22);
    void slot_23(QPixmap* teeth23);
    void slot_24(QPixmap* teeth24);
    void slot_25(QPixmap* teeth25);
    void slot_26(QPixmap* teeth26);
    void slot_27(QPixmap* teeth27);

    /* Bottom Right Teeth */
    void slot_31(QPixmap* teeth31);
    void slot_32(QPixmap* teeth32);
    void slot_33(QPixmap* teeth33);
    void slot_34(QPixmap* teeth34);
    void slot_35(QPixmap* teeth35);
    void slot_36(QPixmap* teeth36);
    void slot_37(QPixmap* teeth37);

    /* Bottom Left Teeth */
    void slot_41(QPixmap* teeth41);
    void slot_42(QPixmap* teeth42);
    void slot_43(QPixmap* teeth43);
    void slot_44(QPixmap* teeth44);
    void slot_45(QPixmap* teeth45);
    void slot_46(QPixmap* teeth46);
    void slot_47(QPixmap* teeth47);


/* EUN JI*/
//------------------------------------------------------------------
    void setPaintSize(qreal);
    void deleteItems();
    void rotate();
//------------------------------------------------------------------


signals:
//    void sig_move(QGraphicsSceneMouseEvent *);

};

#endif // SCENE_H
