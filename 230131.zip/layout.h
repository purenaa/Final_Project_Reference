#ifndef LAYOUT_H
#define LAYOUT_H

#include <QWidget>

class QGraphicsView;
class QGraphicsScene;
class QPushButton;
class QEvent;




class Layout : public QWidget
{
    Q_OBJECT
public:
    explicit Layout(QWidget *parent = nullptr);

    QGraphicsView *grid1;
    QGraphicsView *grid2;
    QGraphicsView *grid3;
    QGraphicsView *grid4;

    QGraphicsScene *scene1;
    QGraphicsScene *scene2;
    QGraphicsScene *scene3;
    QGraphicsScene *scene4;

    QGraphicsView *grid;
    QGraphicsScene *scene;


    QPointF clickPoint;
    bool g = false;


    QMenu* menu;

    QAction* zoomInAction;
    QAction* zoomOutAction;
    QAction* leftRotateAction;
    QAction* rightRotateAction;
    QAction* brushAction;
    QAction* rectangleAction;
    QAction* triangleAction;
    QAction* ellipseAction;
    QAction* moveShapeAction;
    QAction* blendingAction;
    QAction* lengthMeasurementAction;
    QAction* angleMeasurementAction;
    QAction* brightnessAction;
    QAction* darknessAction;
    QAction* sharpenAction;
    QAction* contrastAction;
    QAction* inversionAction;
    QAction* horizontalFlipAction;
    QAction* verticalFlipAction;
    QAction* implantAction;
    QAction* layoutImageClearAction;
    QAction* sourceSizeAction;
    QAction* brushClearActionAction;
    QAction* imageProcessingClearAction;



protected:
    void mousePressEvent(QMouseEvent *event) override;              // 왼쪽 마우스를 눌렀을 때 좌표 위치
    void mouseDoubleClickEvent(QMouseEvent *event) override;        // 왼쪽 마우스 더블 클릭
//    void changeEvent(QEvent *event) override;                     // 윈도우 창 변경될 때
    void resizeEvent(QResizeEvent * event) override;                // 위젯 창 변경될 때


private:
    void gridLayout();
    void actionGroup();



public slots:
    void checkStateShow();





private slots:
    void showMenu(QPointF clickPoint);


signals:
    void sig_size(QGraphicsView *grid);
    void sig_widgetbyDClick(QGraphicsView *grid);

    void sig_point(QPointF);
    void sig_mouseMiddle(QGraphicsView* grid);
};

#endif // LAYOUT_H
