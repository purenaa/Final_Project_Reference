#include "layout.h"
#include "view.h"
#include "menuitem.h"



#include <QGridLayout>
#include <QGraphicsView>

#include <QPixmap>
#include <QMouseEvent>
#include <QMessageBox>

#include <QPushButton>
#include <QSizePolicy>

#include <QMenu>
#include <QStatusBar>
#include <QSettings>

//#include <QGraphicsSceneEvent>


Layout::Layout(QWidget *parent)
    : QWidget{parent}
{
    menuItem = new Menuitem();

    gridLayout();

    scene1 = new QGraphicsScene;
    scene1->setBackgroundBrush(Qt::black);
    scene2 = new QGraphicsScene;
    scene2->setBackgroundBrush(Qt::black);
    scene3 = new QGraphicsScene;
    scene3->setBackgroundBrush(Qt::black);
    scene4 = new QGraphicsScene;
    scene4->setBackgroundBrush(Qt::black);

    grid1->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    grid1->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    grid2->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    grid2->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    grid3->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    grid3->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    grid4->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    grid4->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);


    grid1->setStyleSheet("border: 0.5px solid rgb(129, 134, 143);");
    grid2->setStyleSheet("border: 0.5px solid rgb(129, 134, 143);");
    grid3->setStyleSheet("border: 0.5px solid rgb(129, 134, 143);");
    grid4->setStyleSheet("border: 0.5px solid rgb(129, 134, 143);");

    grid1->setScene(scene1);
    grid2->setScene(scene2);
    grid3->setScene(scene3);
    grid4->setScene(scene4);

    grid = grid1;


    connect(this, SIGNAL(sig_point(QPointF)), this, SLOT(showMenu(QPointF)));

    connect(menuItem->zoomInAction, SIGNAL(triggered()), SLOT(slot_zoomIn()));
    connect(menuItem->zoomOutAction, SIGNAL(triggered()), SLOT(slot_zoomOut()));
    connect(menuItem->leftRotateAction, SIGNAL(triggered()), SLOT(slot_leftRotate()));
    connect(menuItem->rightRotateAction, SIGNAL(triggered()), SLOT(slot_rightRotate()));
    connect(menuItem->sourceSizeAction, SIGNAL(triggered()), SLOT(slot_sourceSize()));
    connect(menuItem->layoutImageClearAction, SIGNAL(triggered()), SLOT(slot_layoutImageClear()));

}

/* 2 X 2 Grid */
void Layout::gridLayout()
{    
    grid1 = new View;
    grid2 = new View;
    grid3 = new View;
    grid4 = new View;

    QHBoxLayout *lay1 = new QHBoxLayout;
    lay1->addWidget(grid1);
    lay1->addSpacing(5);
    lay1->addWidget(grid2);

    QHBoxLayout *lay2 = new QHBoxLayout;
    lay2->addWidget(grid3);
    lay2->addSpacing(5);
    lay2->addWidget(grid4);

    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->addLayout(lay1);
    layout->addSpacing(5);
    layout->addLayout(lay2);
}

void Layout::mousePressEvent(QMouseEvent *event)
{
    qDebug() << "Mouse Pressed" << event->pos();

    if(event->button() == Qt::LeftButton) {
        clickPoint = event->pos();

        int x1 = grid1->pos().x();                 // grid1의 topLeft의 x 좌표값
        int y1 = grid1->pos().y();                 // grid1의 topLeft의 y 좌표값
        int width1 = x1 + grid1->width();          // grid1의 topLeft의 x좌표값에서 grid의 폭만큼 이동한 x의 좌표값
        int height1 = y1 + grid1->height();        // grid1의 topLeft의 y 좌표값에서 grid의 높이만큼 이동한 y의 좌표값

        /* grid2(graphicsView) 의 좌표값 */
        int x2 = grid2->pos().x();
        int y2 = grid2->pos().y();
        int width2 = x2 + grid2->width();
        int height2 = y2 + grid2->height();

        /* grid3(graphicsView) 의 좌표값 */
        int x3 = grid3->pos().x();
        int y3 = grid3->pos().y();
        int width3 = x3 + grid3->width();
        int height3 = y3 + grid3->height();

        /* grid4(graphicsView) 의 좌표값 */
        int x4 = grid4->pos().x();
        int y4 = grid4->pos().y();
        int width4 = x4 + grid4->width();
        int height4 = y4 + grid4->height();

        /* grid 1번 위치 */
        if((clickPoint.x() >= x1 && clickPoint.x() <= width1) && (clickPoint.y() >= y1 && clickPoint.y() <= height1)) {
            g = true;
            grid = grid1;
            scene = scene1;

//            grid1->setStyleSheet("border: 0.5px solid rgb(0,255,0)");
//            grid2->setStyleSheet("border: 0.5px solid rgb(129, 134, 143)");
//            grid3->setStyleSheet("border: 0.5px solid rgb(129, 134, 143)");
//            grid4->setStyleSheet("border: 0.5px solid rgb(129, 134, 143)");

            qDebug("scene1 clicked 1");
        }

        /* grid 2번 위치 */
        else if((clickPoint.x() >= x2 && clickPoint.x() <= width2) && (clickPoint.y() >= y2 && clickPoint.y() <= height2)) {
            g = true;
            grid = grid2;
            scene = scene2;

//            grid2->setStyleSheet("border: 0.5px solid rgb(0,255,0)");
//            grid1->setStyleSheet("border: 0.5px solid rgb(129, 134, 143)");
//            grid3->setStyleSheet("border: 0.5px solid rgb(129, 134, 143)");
//            grid4->setStyleSheet("border: 0.5px solid rgb(129, 134, 143)");

            qDebug("scene2 clicked 2");
        }

        /* grid 3번 위치 */
        else if((clickPoint.x() >= x3 && clickPoint.x() <= width3) && (clickPoint.y() >= y3 && clickPoint.y() <= height3)) {
            g = true;
            grid = grid3;
            scene = scene3;

//            grid3->setStyleSheet("border: 0.5px solid rgb(0,255,0)");
//            grid1->setStyleSheet("border: 0.5px solid rgb(129, 134, 143)");
//            grid2->setStyleSheet("border: 0.5px solid rgb(129, 134, 143)");
//            grid4->setStyleSheet("border: 0.5px solid rgb(129, 134, 143)");

            qDebug("scene3 clicked 3");
        }

        /* grid 4번 위치 */
        else if((clickPoint.x() >= x4 && clickPoint.x() <= width4) && (clickPoint.y() >= y4 && clickPoint.y() <= height4)) {
            //grid4->setScene(scene4);
            g = true;
            grid = grid4;
            scene = scene4;

//            grid4->setStyleSheet("border: 0.5px solid rgb(0,255,0)");
//            grid1->setStyleSheet("border: 0.5px solid rgb(129, 134, 143)");
//            grid2->setStyleSheet("border: 0.5px solid rgb(129, 134, 143)");
//            grid3->setStyleSheet("border: 0.5px solid rgb(129, 134, 143)");

            qDebug("scene4 clicked 4");
        }
        qDebug("시그널");
    }

    /* 클릭 단축키 */
    if(event->button() == Qt::MiddleButton) {

        qDebug() << "마우스 가운데 클릭";
        clickPoint = event->pos();

        if((clickPoint.x() >= grid1->pos().x() && clickPoint.x() <= grid1->pos().x() + grid1->width())
                && (clickPoint.y() >= grid1->pos().y() && clickPoint.y() <= grid1->pos().y() + grid1->height())) {

            grid = grid1;
            emit sig_point(clickPoint);
            qDebug() << "1";

        }
        else if((clickPoint.x() >= grid2->pos().x() && clickPoint.x() <= grid2->pos().x() + grid2->width())
                && (clickPoint.y() >= grid2->pos().y() && clickPoint.y() <= grid2->pos().y() + grid2->height())) {

            grid = grid2;
            emit sig_point(clickPoint);
            qDebug() << "2";

        }
        else if((clickPoint.x() >= grid3->pos().x() && clickPoint.x() <= grid3->pos().x() + grid3->width())
                && (clickPoint.y() >= grid3->pos().y() && clickPoint.y() <= grid3->pos().y() + grid3->height())) {

            grid = grid3;
            emit sig_point(clickPoint);
            qDebug() << "3";

        }
        else if((clickPoint.x() >= grid4->pos().x() && clickPoint.x() <= grid4->pos().x() + grid4->width())
                && (clickPoint.y() >= grid4->pos().y() && clickPoint.y() <= grid4->pos().y() + grid4->height())) {

            grid = grid4;
            emit sig_point(clickPoint);
            qDebug() << "4";
        }
    }
}


void Layout::mouseDoubleClickEvent(QMouseEvent *event)
{
    qDebug() << "Mouse mouseDoubleClickEvent" << event->pos();

    if(event->button() == Qt::LeftButton) {
        clickPoint = event->pos();

        if((clickPoint.x() >= grid1->pos().x() && clickPoint.x() <= grid1->pos().x() + grid1->width())
                && (clickPoint.y() >= grid1->pos().y() && clickPoint.y() <= grid1->pos().y() + grid1->height())) {

            grid = grid1;
            emit sig_widgetbyDClick(grid);

            qDebug() << "Double check1";
        }
        else if((clickPoint.x() >= grid2->pos().x() && clickPoint.x() <= grid2->pos().x() + grid2->width())
                && (clickPoint.y() >= grid2->pos().y() && clickPoint.y() <= grid2->pos().y() + grid2->height())) {

            grid = grid2;
            emit sig_widgetbyDClick(grid);

            qDebug() << "Double check2";
        }
        else if((clickPoint.x() >= grid3->pos().x() && clickPoint.x() <= grid3->pos().x() + grid3->width())
                && (clickPoint.y() >= grid3->pos().y() && clickPoint.y() <= grid3->pos().y() + grid3->height())) {

            grid = grid3;
            emit sig_widgetbyDClick(grid);

            qDebug() << "Double check3";
        }
        else if((clickPoint.x() >= grid4->pos().x() && clickPoint.x() <= grid4->pos().x() + grid4->width())
                && (clickPoint.y() >= grid4->pos().y() && clickPoint.y() <= grid4->pos().y() + grid4->height())) {

            grid = grid4;
            emit sig_widgetbyDClick(grid);

            qDebug() << "Double check4";
        }
    }
}


void Layout::showMenu(QPointF clickPoint)
{
    checkStateShow();               // 체크 상태 된 기능만 메뉴바에 생성됨
    QPoint point = this->mapToGlobal(clickPoint.toPoint());
    menuItem->menu->exec(point);


    qDebug() << "showMenu" << point;
}


void Layout::checkStateShow()
{
    QSettings CheckBox(QString("./CheckBox/%1.ini").arg("CheckStateFile"), QSettings::IniFormat);
    CheckBox.beginGroup("checking");

    menuItem->menu->clear();

    if(CheckBox.value("checkState1") == true)
        menuItem->menu->addAction(menuItem->zoomInAction);
    if(CheckBox.value("checkState2") == true)
        menuItem->menu->addAction(menuItem->zoomOutAction);
    if(CheckBox.value("checkState3") == true)
        menuItem->menu->addAction(menuItem->leftRotateAction);
    if(CheckBox.value("checkState4") == true)
        menuItem->menu->addAction(menuItem->rightRotateAction);
    if(CheckBox.value("checkState5") == true)
        menuItem->menu->addAction(menuItem->brushAction);
    if(CheckBox.value("checkState6") == true)
        menuItem->menu->addAction(menuItem->rectangleAction);
    if(CheckBox.value("checkState7") == true)
        menuItem->menu->addAction(menuItem->triangleAction);
    if(CheckBox.value("checkState8") == true)
        menuItem->menu->addAction(menuItem->ellipseAction);
    if(CheckBox.value("checkState9") == true)
        menuItem->menu->addAction(menuItem->moveShapeAction);
    if(CheckBox.value("checkState10") == true)
        menuItem->menu->addAction(menuItem->blendingAction);
    if(CheckBox.value("checkState11") == true)
        menuItem->menu->addAction(menuItem->lengthMeasurementAction);
    if(CheckBox.value("checkState12") == true)
        menuItem->menu->addAction(menuItem->angleMeasurementAction);
    if(CheckBox.value("checkState13") == true)
        menuItem->menu->addAction(menuItem->brightnessAction);
    if(CheckBox.value("checkState14") == true)
        menuItem->menu->addAction(menuItem->darknessAction);
    if(CheckBox.value("checkState15") == true)
        menuItem->menu->addAction(menuItem->sharpenAction);
    if(CheckBox.value("checkState16") == true)
        menuItem->menu->addAction(menuItem->contrastAction);
    if(CheckBox.value("checkState17") == true)
        menuItem->menu->addAction(menuItem->inversionAction);
    if(CheckBox.value("checkState18") == true)
        menuItem->menu->addAction(menuItem->horizontalFlipAction);
    if(CheckBox.value("checkState19") == true)
        menuItem->menu->addAction(menuItem->verticalFlipAction);
    if(CheckBox.value("checkState20") == true)
        menuItem->menu->addAction(menuItem->implantAction);
    if(CheckBox.value("checkState21") == true)
        menuItem->menu->addAction(menuItem->sourceSizeAction);
    if(CheckBox.value("checkState22") == true)
        menuItem->menu->addAction(menuItem->layoutImageClearAction);
    if(CheckBox.value("checkState23") == true)
        menuItem->menu->addAction(menuItem->brushClearActionAction);
    if(CheckBox.value("checkState24") == true)
        menuItem->menu->addAction(menuItem->imageProcessingClearAction);
    CheckBox.endGroup();
}

void Layout::slot_zoomIn()
{
    grid->scale(2, 2);
    grid->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    grid->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
}

void Layout::slot_zoomOut()
{
    grid->scale(0.8, 0.8);
    grid->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    grid->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
}

void Layout::slot_leftRotate()
{
    grid->rotate(90);
    grid->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    grid->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
}

void Layout::slot_rightRotate()
{
    grid->rotate(-90);
    grid->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    grid->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
}

void Layout::slot_sourceSize()
{
    grid->resetTransform();
}

void Layout::slot_layoutImageClear()
{
    grid1->resetTransform();
    grid2->resetTransform();
    grid3->resetTransform();
    grid4->resetTransform();

    grid1->scene()->clear();
    grid2->scene()->clear();
    grid3->scene()->clear();
    grid4->scene()->clear();

    grid1->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    grid1->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    grid2->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    grid2->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    grid3->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    grid3->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    grid4->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    grid4->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

//    cnt = 0;
}



void Layout::resizeEvent(QResizeEvent* event)
{
    Q_UNUSED(event);
    emit sig_size(grid);
}


