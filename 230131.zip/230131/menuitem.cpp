#include "menuitem.h"


#include <QMenu>
#include <QStatusBar>
#include <QGraphicsView>


Menuitem::Menuitem(QWidget *parent)
    : QWidget{parent}
{
    menu = new QMenu;    // menu : 멤버변수, 메뉴 생성

    zoomInAction = new QAction(tr("&Zoom In"));
    zoomOutAction = new QAction(tr("&Zoom Out"));
    leftRotateAction = new QAction(tr("&90° Rotate"));
    rightRotateAction = new QAction(tr("&-90° Rotate"));
    brushAction = new QAction(tr("&Brush"));
    rectangleAction = new QAction(tr("&Rectangle"));
    triangleAction = new QAction(tr("&Triangle"));
    ellipseAction = new QAction(tr("&Ellipse"));
    moveShapeAction = new QAction(tr("&Move Shape"));
    blendingAction = new QAction(tr("&Blending"));
    lengthMeasurementAction = new QAction(tr("&Length Measurement"));
    angleMeasurementAction = new QAction(tr("&Angle Measurement"));
    brightnessAction = new QAction(tr("&Brightness"));
    darknessAction = new QAction(tr("&Darkness"));
    sharpenAction = new QAction(tr("&Sharpen"));
    contrastAction = new QAction(tr("&Contrast"));
    inversionAction = new QAction(tr("&Inversion"));
    horizontalFlipAction = new QAction(tr("&Horizontal Flip"));
    verticalFlipAction = new QAction(tr("&Vertical Flip"));
    implantAction = new QAction(tr("&Implant"));
    sourceSizeAction = new QAction(tr("&Source Size"));
    layoutImageClearAction = new QAction(tr("&Layout Image Clear"));
    brushClearActionAction = new QAction(tr("&Brush Clear"));
    imageProcessingClearAction = new QAction(tr("&Image Processing"));
}


