#include "maxlayout.h"

#include <QGraphicsView>
#include <QBoxLayout>
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include <QPixmap>
#include <QPushButton>
Maxlayout::Maxlayout(QWidget *parent)
    : QWidget{parent}
{

    /* 시도 1 */
    maxWidget = new QWidget();
    maxNewGrid = new QGraphicsView;
    maxLayBox = new QHBoxLayout(this);
    maxLayBox->addWidget(maxNewGrid);
    maxLayBox->setContentsMargins(0,0,0,0);
    maxNewSc = new QGraphicsScene;
    maxNewSc->setBackgroundBrush(Qt::yellow);
    maxNewGrid->setScene(maxNewSc);


    QPushButton *viewQuit = new QPushButton("X", this);
    viewQuit->setGeometry(this->width()-50, 10, 30, 30);
    viewQuit->setStyleSheet("background:rgb(255, 255, 255)");


}

void Maxlayout::resizeEvent(QResizeEvent* event)
{
    qDebug() << "gridWidget changed";
//    w = true;
    emit max_sig_size(maxNewGrid);
}

void Maxlayout::setNewSc(QGraphicsScene* sc)
{
    qDebug() << "maxNewGrid changed";
    maxNewSc = sc;
    maxNewGrid->setScene(maxNewSc);
}
void Maxlayout::setNewGrid(QGraphicsView* view)
{
    maxNewGrid = view;
}



