#ifndef MAXLAYOUT_H
#define MAXLAYOUT_H

#include <QWidget>

class QHBoxLayout;
class QGraphicsView;
class QGraphicsScene;

class Maxlayout : public QWidget
{
    Q_OBJECT
public:
    explicit Maxlayout(QWidget *parent = nullptr);
    void setNewSc(QGraphicsScene*);
    void setNewGrid(QGraphicsView*);
    QGraphicsView *maxNewGrid;
    QGraphicsScene *maxNewSc;
protected:
    void resizeEvent(QResizeEvent * event) override;

private:
    QWidget *maxWidget;
    QHBoxLayout *maxLayBox;

signals:
    void max_sig_size(QGraphicsView *);
    //void sig_widgetbyDClick(QGraphicsView *grid, QGraphicsScene *scene);


};



#endif // MAXLAYOUT_H
